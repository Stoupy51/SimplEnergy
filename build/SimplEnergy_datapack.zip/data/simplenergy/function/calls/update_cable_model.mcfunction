
#> simplenergy:calls/update_cable_model
#
# @within	simplenergy:calls/update_cable
#

# Calculate the model
execute store result score #model simplenergy.data run data get entity @s item.components."minecraft:custom_model_data"
scoreboard players operation #model simplenergy.data /= #100 simplenergy.data
scoreboard players operation #model simplenergy.data *= #100 simplenergy.data
scoreboard players operation #model simplenergy.data += @s energy.data

# Apply the model
execute store result entity @s item.components."minecraft:custom_model_data" int 1 run scoreboard players get #model simplenergy.data
scoreboard players reset #model simplenergy.data

