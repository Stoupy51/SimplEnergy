
#> simplenergy:calls/update_energy_lore/macro
#
# @executed	as @n[type=item,nbt={Item:{id:"minecraft:gold_block"}},distance=..1]
#
# @within	simplenergy:calls/update_energy_lore/main with storage simplenergy:temp macro
#
# @args		part_1 (int)
#			pad (string)
#			part_2 (int)
#			scale (string)
#

$execute unless data storage energy:temp list[0].components."minecraft:custom_data".energy.has_storage_lore run data modify storage energy:temp list[0].components."minecraft:lore" insert -2 value [[{"text":"[","color":"gray","italic":false}, {"translate":"simplenergy.charge","fallback":"Charge: "}],"$(part_1).$(pad)$(part_2)$(scale)"]
$execute if data storage energy:temp list[0].components."minecraft:custom_data".energy.has_storage_lore run data modify storage energy:temp list[0].components."minecraft:lore"[-2] set value [[{"text":"[","color":"gray","italic":false}, {"translate":"simplenergy.charge","fallback":"Charge: "}],"$(part_1).$(pad)$(part_2)$(scale)"]

