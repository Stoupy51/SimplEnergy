
#> simplenergy:custom_blocks/electric_brewing_stand/place_secondary
#
# @executed	at @s
#
# @within	simplenergy:custom_blocks/electric_brewing_stand/place_main [ at @s ]
#

# Add convention and utils tags, and the custom block tag
tag @s add global.ignore
tag @s add global.ignore.kill
tag @s add smithed.entity
tag @s add smithed.block
tag @s add simplenergy.custom_block
tag @s add simplenergy.electric_brewing_stand
tag @s add simplenergy.vanilla.minecraft_brewing_stand

# Add a custom name
data merge entity @s {"CustomName": {"translate": "simplenergy.electric_brewing_stand"}}

# Modify item display entity to match the custom block
item replace entity @s contents with minecraft:furnace[item_model="simplenergy:electric_brewing_stand"]
data modify entity @s transformation.scale set value [1.002f,1.002f,1.002f]
function simplenergy:custom_blocks/compute_brightness

# Energy part
tag @s add energy.receive
scoreboard players set @s simplenergy.energy_rate 40
scoreboard players set @s energy.max_storage 2400
scoreboard players operation @s energy.transfer_rate = @s energy.max_storage
scoreboard players add @s energy.storage 0
scoreboard players add @s energy.change_rate 0
function energy:v1/api/init_machine

# ItemIO compatibility
tag @s add itemio.container
tag @s add itemio.container.hopper
data modify entity @s item.components."minecraft:custom_data".itemio.ioconfig set value []
data modify entity @s item.components."minecraft:custom_data".itemio.ioconfig append value {"Slot":3b,"mode":"input","allowed_side":{"north":true,"south":true,"east":true,"west":true,"top":true}}
data modify entity @s item.components."minecraft:custom_data".itemio.ioconfig append value {"Slot":0b,"mode":"output","allowed_side":{"bottom":true,"north":true,"south":true,"east":true,"west":true}}
data modify entity @s item.components."minecraft:custom_data".itemio.ioconfig append value {"Slot":1b,"mode":"output","allowed_side":{"bottom":true,"north":true,"south":true,"east":true,"west":true}}
data modify entity @s item.components."minecraft:custom_data".itemio.ioconfig append value {"Slot":2b,"mode":"output","allowed_side":{"bottom":true,"north":true,"south":true,"east":true,"west":true}}
function #itemio:calls/container/init

# Rotate the entity and set scale
data modify entity @s Rotation[0] set value 180.0f
data modify entity @s transformation.scale[1] set value 1.025f
data modify entity @s transformation.translation[1] set value 0.01f

# Add tag for loop every tick
tag @s add simplenergy.tick
scoreboard players add #tick_entities simplenergy.data 1

## sourceMappingURL=place_secondary.mcfunction.map
