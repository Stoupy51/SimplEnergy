
#> simplenergy:custom_blocks/_player_head/search_advanced_cable_z
#
# @executed	positioned ~ ~-8 ~
#
# @within	simplenergy:custom_blocks/_player_head/search_advanced_cable_y [ positioned ~ ~-8 ~ ]
#			simplenergy:custom_blocks/_player_head/search_advanced_cable_y [ positioned ~ ~-7 ~ ]
#			simplenergy:custom_blocks/_player_head/search_advanced_cable_y [ positioned ~ ~-6 ~ ]
#			simplenergy:custom_blocks/_player_head/search_advanced_cable_y [ positioned ~ ~-5 ~ ]
#			simplenergy:custom_blocks/_player_head/search_advanced_cable_y [ positioned ~ ~-4 ~ ]
#			simplenergy:custom_blocks/_player_head/search_advanced_cable_y [ positioned ~ ~-3 ~ ]
#			simplenergy:custom_blocks/_player_head/search_advanced_cable_y [ positioned ~ ~-2 ~ ]
#			simplenergy:custom_blocks/_player_head/search_advanced_cable_y [ positioned ~ ~-1 ~ ]
#			simplenergy:custom_blocks/_player_head/search_advanced_cable_y [ positioned ~ ~0 ~ ]
#			simplenergy:custom_blocks/_player_head/search_advanced_cable_y [ positioned ~ ~1 ~ ]
#			simplenergy:custom_blocks/_player_head/search_advanced_cable_y [ positioned ~ ~2 ~ ]
#			simplenergy:custom_blocks/_player_head/search_advanced_cable_y [ positioned ~ ~3 ~ ]
#			simplenergy:custom_blocks/_player_head/search_advanced_cable_y [ positioned ~ ~4 ~ ]
#			simplenergy:custom_blocks/_player_head/search_advanced_cable_y [ positioned ~ ~5 ~ ]
#			simplenergy:custom_blocks/_player_head/search_advanced_cable_y [ positioned ~ ~6 ~ ]
#			simplenergy:custom_blocks/_player_head/search_advanced_cable_y [ positioned ~ ~7 ~ ]
#			simplenergy:custom_blocks/_player_head/search_advanced_cable_y [ positioned ~ ~8 ~ ]
#

# Search z coordinates
execute positioned ~ ~ ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.advanced_cable run function simplenergy:custom_blocks/advanced_cable/place_main
execute positioned ~ ~ ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.advanced_cable run function simplenergy:custom_blocks/advanced_cable/place_main
execute positioned ~ ~ ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.advanced_cable run function simplenergy:custom_blocks/advanced_cable/place_main
execute positioned ~ ~ ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.advanced_cable run function simplenergy:custom_blocks/advanced_cable/place_main
execute positioned ~ ~ ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.advanced_cable run function simplenergy:custom_blocks/advanced_cable/place_main
execute positioned ~ ~ ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.advanced_cable run function simplenergy:custom_blocks/advanced_cable/place_main
execute positioned ~ ~ ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.advanced_cable run function simplenergy:custom_blocks/advanced_cable/place_main
execute positioned ~ ~ ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.advanced_cable run function simplenergy:custom_blocks/advanced_cable/place_main
execute positioned ~ ~ ~0 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.advanced_cable run function simplenergy:custom_blocks/advanced_cable/place_main
execute positioned ~ ~ ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.advanced_cable run function simplenergy:custom_blocks/advanced_cable/place_main
execute positioned ~ ~ ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.advanced_cable run function simplenergy:custom_blocks/advanced_cable/place_main
execute positioned ~ ~ ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.advanced_cable run function simplenergy:custom_blocks/advanced_cable/place_main
execute positioned ~ ~ ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.advanced_cable run function simplenergy:custom_blocks/advanced_cable/place_main
execute positioned ~ ~ ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.advanced_cable run function simplenergy:custom_blocks/advanced_cable/place_main
execute positioned ~ ~ ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.advanced_cable run function simplenergy:custom_blocks/advanced_cable/place_main
execute positioned ~ ~ ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.advanced_cable run function simplenergy:custom_blocks/advanced_cable/place_main
execute positioned ~ ~ ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.advanced_cable run function simplenergy:custom_blocks/advanced_cable/place_main

