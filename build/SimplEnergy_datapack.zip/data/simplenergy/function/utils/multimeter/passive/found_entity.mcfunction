
#> simplenergy:utils/multimeter/passive/found_entity
#
# @within	simplenergy:utils/multimeter/passive/stop_case
#

# Summon glowing snowball on block
execute unless block ~ ~ ~ #simplenergy:non_solid run summon snowball ~0.5 ~0.3 ~0.5 {NoGravity:1b,Silent:1b,Glowing:1b,Tags:["simplenergy.multimeter_marker"]}

# Title to the player
title @a[tag=simplenergy.temp] actionbar [{"translate": "simplenergy.energy_stored",italic:false,color:"aqua"},{score:{name:"@s",objective:"energy.storage"},italic:false,color:"yellow"},{text:"/"},{score:{name:"@s",objective:"energy.max_storage"},italic:false,color:"yellow"},{text:" kJ"},{text:"  |  ",color:"yellow"},{"translate": "simplenergy.change_rate"},{score:{name:"@s",objective:"energy.change_rate"},italic:false,color:"yellow"},{text:" kW"}]

# Remove the snowball by schedule function
schedule function simplenergy:utils/multimeter/passive/remove_markers 1 replace

