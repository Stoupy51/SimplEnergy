
#> simplenergy:v2.4.1/load/tick_verification
#
# @within	#minecraft:tick
#

execute if score #simplenergy.major load.status matches 2 if score #simplenergy.minor load.status matches 4 if score #simplenergy.patch load.status matches 1 run function simplenergy:v2.4.1/tick

