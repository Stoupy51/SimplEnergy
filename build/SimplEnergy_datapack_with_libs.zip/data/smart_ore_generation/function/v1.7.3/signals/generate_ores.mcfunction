
#> smart_ore_generation:v1.7.3/signals/generate_ores
#
# @executed	as a special marker & at a position you shouldn't care about
#
# @within	#smart_ore_generation:v1/signals/generate_ores
#
#  WARNING!
# - You must not use /kill @s in this file, or the entire library will stop working.
# - Don't forget to edit #min_height and #max_height scores before trying to generate ores.
#

## Example of a function to generate ores in smart_ore_generation:v1/signals/example/generate_ores
# You can use this function as a template to create your own functions.

