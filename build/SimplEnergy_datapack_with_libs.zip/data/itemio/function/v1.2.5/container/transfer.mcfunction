scoreboard players set #success_transfer itemio.io 0
execute if score #loaded itemio.math matches 1 run function itemio:v1.2.5/container/transfer_2
