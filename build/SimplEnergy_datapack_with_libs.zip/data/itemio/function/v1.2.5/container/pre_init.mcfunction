execute if entity @s[type=#itemio:container] run function itemio:v1.2.5/container/init
