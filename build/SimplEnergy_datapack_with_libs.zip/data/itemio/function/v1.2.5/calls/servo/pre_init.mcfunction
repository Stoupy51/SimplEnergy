execute if score #itemio.major load.status matches 1 if score #itemio.minor load.status matches 2 if score #itemio.patch load.status matches 5 run function itemio:v1.2.5/servo/pre_init
