execute if entity @s[tag=!itemio.network.already_regenerated] run function itemio:v1.2.5/cable/destroy/regen
