execute if entity @s[type=#itemio:cables] at @s run function itemio:v1.2.5/cable/init
