
# brewing_stand
# There are using a custom ioconfig

data modify storage itemio:main.output ioconfig set value [{Slot: 0b, allowed_side: {north: 1b, south: 1b, east: 1b, west: 1b}}, {Slot: 1b, allowed_side: {north: 1b, south: 1b, east: 1b, west: 1b}}, {Slot: 2b, allowed_side: {north: 1b, south: 1b, east: 1b, west: 1b}}, {Slot: 3b, allowed_side: {top: 1b}}, {Slot: 4b, allowed_side: {north: 1b, south: 1b, east: 1b, west: 1b}}]

function itemio:v1.4.1/container/output/custom/output_noconfig
