
scoreboard players set #filter.valid_item itemio.io 0
data remove entity @s equipment.mainhand
data modify entity @s equipment.mainhand set from storage itemio:io item
execute if predicate itemio:v1.4.1/minecraft/creeper_drop_music_discs run scoreboard players set #filter.valid_item itemio.io 1
