
execute if entity @s[tag=!itemio.network.already_regenerated] run function itemio:v1.4.1/cable/destroy/regen
