
execute if score #itemio.major load.status matches 1 if score #itemio.minor load.status matches 4 if score #itemio.patch load.status matches 0 run function itemio:v1.4.0/container/auto_handled_output/repart
