
# @public

execute if entity @s[type=#itemio:container] run function itemio:v1.4.0/container/init
