
# @public

execute if entity @s[type=#itemio:cables] at @s run function itemio:v1.4.0/cable/init
