
# @public

execute if entity @s[type=#itemio:container] run function itemio:v1.3.2/container/init
