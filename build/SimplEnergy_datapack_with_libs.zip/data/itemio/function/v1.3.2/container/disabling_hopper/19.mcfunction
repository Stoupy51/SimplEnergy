
execute if predicate itemio:v1.3.2/container/hopper_x_plus_1.9 positioned ~1.9 ~ ~ run function itemio:v1.3.2/container/hopper

execute if predicate itemio:v1.3.2/container/hopper_z_plus_1.9 positioned ~ ~ ~1.9 run function itemio:v1.3.2/container/hopper

execute if predicate itemio:v1.3.2/container/hopper_x_minus_1.9 positioned ~-1.9 ~ ~ run function itemio:v1.3.2/container/hopper

execute if predicate itemio:v1.3.2/container/hopper_z_minus_1.9 positioned ~ ~ ~-1.9 run function itemio:v1.3.2/container/hopper
