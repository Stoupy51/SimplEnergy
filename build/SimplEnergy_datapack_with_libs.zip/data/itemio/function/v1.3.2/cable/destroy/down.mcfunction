
execute if entity @s[tag=!itemio.network.already_regenerated] run function itemio:v1.3.2/cable/destroy/regen
