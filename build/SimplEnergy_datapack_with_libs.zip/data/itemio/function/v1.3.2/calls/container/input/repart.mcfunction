
execute if score #itemio.major load.status matches 1 if score #itemio.minor load.status matches 3 if score #itemio.patch load.status matches 2 run function itemio:v1.3.2/container/input/repart
