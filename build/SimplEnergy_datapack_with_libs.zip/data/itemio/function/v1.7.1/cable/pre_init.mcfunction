
# @public

execute if entity @s[type=#itemio:cables] at @s run function itemio:v1.7.1/cable/init
