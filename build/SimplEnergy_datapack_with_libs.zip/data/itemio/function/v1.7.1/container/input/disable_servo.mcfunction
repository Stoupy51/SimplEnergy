
# @public

execute as @e[tag=itemio.servo.initialised, distance=..1.5] run function itemio:v1.7.1/container/input/disable_servo/random_cooldown

kill @e[tag=itemio.transfer.destination.temp, distance=..0.5001]
