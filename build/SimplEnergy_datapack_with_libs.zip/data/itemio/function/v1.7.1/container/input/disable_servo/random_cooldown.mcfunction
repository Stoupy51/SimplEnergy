
# @public

execute store result score @s itemio.servo.cooldown run random value 75..200
scoreboard players operation @s itemio.servo.cooldown += #global_tick itemio.math
