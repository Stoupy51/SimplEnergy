
# @public

execute if entity @s[type=#itemio:container] run function itemio:v1.7.1/container/init
