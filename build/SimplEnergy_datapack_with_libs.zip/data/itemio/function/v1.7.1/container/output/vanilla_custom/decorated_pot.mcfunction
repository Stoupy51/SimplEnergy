
data remove storage itemio:main.output ItemUnique
data modify storage itemio:main.output ItemUnique set from block ~ ~ ~ item

function itemio:v1.7.1/container/output/vanilla_custom/single_item/main
