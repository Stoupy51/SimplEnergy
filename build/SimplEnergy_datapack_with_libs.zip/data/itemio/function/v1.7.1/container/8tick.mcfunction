
execute align xyz positioned ~0.5 ~0.5 ~0.5 run function itemio:v1.7.1/container/hopper_v2/repart_all
