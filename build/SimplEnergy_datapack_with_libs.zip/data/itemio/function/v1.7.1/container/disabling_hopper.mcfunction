
execute if entity @s[tag=itemio.container.hopper_protection_1] run function itemio:v1.7.1/container/disabling_hopper/1

execute if entity @s[tag=itemio.container.hopper_protection_2] run function itemio:v1.7.1/container/disabling_hopper/2
execute if entity @s[tag=itemio.container.hopper_protection_3] run function itemio:v1.7.1/container/disabling_hopper/3
execute if entity @s[tag=itemio.container.hopper_protection_4] run function itemio:v1.7.1/container/disabling_hopper/4
execute if entity @s[tag=itemio.container.hopper_protection_5] run function itemio:v1.7.1/container/disabling_hopper/5
execute if entity @s[tag=itemio.container.hopper_protection_6] run function itemio:v1.7.1/container/disabling_hopper/6

execute if entity @s[tag=itemio.container.hopper_protection_7] run function itemio:v1.7.1/container/disabling_hopper/7
execute if entity @s[tag=itemio.container.hopper_protection_8] run function itemio:v1.7.1/container/disabling_hopper/8
execute if entity @s[tag=itemio.container.hopper_protection_9] run function itemio:v1.7.1/container/disabling_hopper/9
execute if entity @s[tag=itemio.container.hopper_protection_10] run function itemio:v1.7.1/container/disabling_hopper/10

execute if entity @s[tag=itemio.container.hopper_protection_11] run function itemio:v1.7.1/container/disabling_hopper/11
execute if entity @s[tag=itemio.container.hopper_protection_12] run function itemio:v1.7.1/container/disabling_hopper/12
execute if entity @s[tag=itemio.container.hopper_protection_13] run function itemio:v1.7.1/container/disabling_hopper/13
execute if entity @s[tag=itemio.container.hopper_protection_14] run function itemio:v1.7.1/container/disabling_hopper/14

execute if entity @s[tag=itemio.container.hopper_protection_15] run function itemio:v1.7.1/container/disabling_hopper/15
execute if entity @s[tag=itemio.container.hopper_protection_16] run function itemio:v1.7.1/container/disabling_hopper/16
execute if entity @s[tag=itemio.container.hopper_protection_17] run function itemio:v1.7.1/container/disabling_hopper/17
execute if entity @s[tag=itemio.container.hopper_protection_18] run function itemio:v1.7.1/container/disabling_hopper/18

execute if entity @s[tag=itemio.container.hopper_protection_19] run function itemio:v1.7.1/container/disabling_hopper/19

execute if predicate itemio:v1.7.1/hopper run function itemio:v1.7.1/container/hopper

execute if predicate itemio:v1.7.1/activator_rail run function itemio:v1.7.1/container/activator_rail
