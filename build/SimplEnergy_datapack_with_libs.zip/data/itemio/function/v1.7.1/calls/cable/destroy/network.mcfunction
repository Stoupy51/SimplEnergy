
execute if score #itemio.major load.status matches 1 if score #itemio.minor load.status matches 7 if score #itemio.patch load.status matches 1 run function itemio:v1.7.1/cable/destroy/network
