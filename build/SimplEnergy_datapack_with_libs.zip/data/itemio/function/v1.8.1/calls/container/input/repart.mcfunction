
execute if score #itemio.major load.status matches 1 if score #itemio.minor load.status matches 8 if score #itemio.patch load.status matches 1 run function itemio:v1.8.1/container/input/repart
