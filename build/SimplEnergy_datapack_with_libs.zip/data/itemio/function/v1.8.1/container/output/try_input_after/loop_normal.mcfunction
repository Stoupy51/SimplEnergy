
#sayloop_normal

scoreboard players set #success_input itemio.io 0
function itemio:v1.8.1/container/output/try_input_after/input
