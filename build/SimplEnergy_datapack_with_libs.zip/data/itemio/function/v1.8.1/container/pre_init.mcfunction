
# @public

execute if entity @s[type=#itemio:container] run function itemio:v1.8.1/container/init
