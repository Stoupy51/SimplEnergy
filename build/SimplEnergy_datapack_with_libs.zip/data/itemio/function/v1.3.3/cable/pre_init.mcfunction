
# @public

execute if entity @s[type=#itemio:cables] at @s run function itemio:v1.3.3/cable/init
