
execute if predicate itemio:v1.3.3/container/hopper_x_plus_1.6 positioned ~1.6 ~ ~ run function itemio:v1.3.3/container/hopper

execute if predicate itemio:v1.3.3/container/hopper_z_plus_1.6 positioned ~ ~ ~1.6 run function itemio:v1.3.3/container/hopper

execute if predicate itemio:v1.3.3/container/hopper_x_minus_1.6 positioned ~-1.6 ~ ~ run function itemio:v1.3.3/container/hopper

execute if predicate itemio:v1.3.3/container/hopper_z_minus_1.6 positioned ~ ~ ~-1.6 run function itemio:v1.3.3/container/hopper
