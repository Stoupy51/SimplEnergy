
execute if predicate itemio:v1.3.3/container/hopper_x_plus_0.5 positioned ~0.5 ~ ~ run function itemio:v1.3.3/container/hopper

execute if predicate itemio:v1.3.3/container/hopper_z_plus_0.5 positioned ~ ~ ~0.5 run function itemio:v1.3.3/container/hopper

execute if predicate itemio:v1.3.3/container/hopper_x_minus_0.5 positioned ~-0.5 ~ ~ run function itemio:v1.3.3/container/hopper

execute if predicate itemio:v1.3.3/container/hopper_z_minus_0.5 positioned ~ ~ ~-0.5 run function itemio:v1.3.3/container/hopper
