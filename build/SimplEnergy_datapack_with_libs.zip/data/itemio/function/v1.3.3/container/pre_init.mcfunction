
# @public

execute if entity @s[type=#itemio:container] run function itemio:v1.3.3/container/init
