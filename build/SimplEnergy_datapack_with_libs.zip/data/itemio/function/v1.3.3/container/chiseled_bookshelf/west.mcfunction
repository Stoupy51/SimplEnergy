
                #raw f"$say {slot}, {face}, $(chiseled_bookshelf_args)"

function itemio:v1.3.3/container/chiseled_bookshelf/west/slot_0 with storage itemio:main temp
function itemio:v1.3.3/container/chiseled_bookshelf/west/slot_1 with storage itemio:main temp
function itemio:v1.3.3/container/chiseled_bookshelf/west/slot_2 with storage itemio:main temp
function itemio:v1.3.3/container/chiseled_bookshelf/west/slot_3 with storage itemio:main temp
function itemio:v1.3.3/container/chiseled_bookshelf/west/slot_4 with storage itemio:main temp

function itemio:v1.3.3/container/chiseled_bookshelf/west/slot_5 with storage itemio:main temp

function itemio:v1.3.3/container/chiseled_bookshelf/west_retrieve with storage itemio:main temp
