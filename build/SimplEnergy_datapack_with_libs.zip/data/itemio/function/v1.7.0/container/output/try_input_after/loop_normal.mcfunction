
#sayloop_normal

scoreboard players set #success_input itemio.io 0
function itemio:v1.7.0/container/output/try_input_after/input
