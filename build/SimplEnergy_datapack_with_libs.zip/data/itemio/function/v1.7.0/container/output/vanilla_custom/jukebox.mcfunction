
data remove storage itemio:main.output ItemUnique
data modify storage itemio:main.output ItemUnique set from block ~ ~ ~ RecordItem

function itemio:v1.7.0/container/output/vanilla_custom/single_item/main
