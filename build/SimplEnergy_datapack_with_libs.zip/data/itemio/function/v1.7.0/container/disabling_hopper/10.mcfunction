
execute if predicate itemio:v1.7.0/container/hopper_x_plus_1.0 positioned ~1.0 ~ ~ run function itemio:v1.7.0/container/hopper

execute if predicate itemio:v1.7.0/container/hopper_z_plus_1.0 positioned ~ ~ ~1.0 run function itemio:v1.7.0/container/hopper

execute if predicate itemio:v1.7.0/container/hopper_x_minus_1.0 positioned ~-1.0 ~ ~ run function itemio:v1.7.0/container/hopper

execute if predicate itemio:v1.7.0/container/hopper_z_minus_1.0 positioned ~ ~ ~-1.0 run function itemio:v1.7.0/container/hopper
