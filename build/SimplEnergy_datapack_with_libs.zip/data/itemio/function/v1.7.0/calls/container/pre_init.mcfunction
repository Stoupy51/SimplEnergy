
execute if score #itemio.major load.status matches 1 if score #itemio.minor load.status matches 7 if score #itemio.patch load.status matches 0 run function itemio:v1.7.0/container/pre_init
