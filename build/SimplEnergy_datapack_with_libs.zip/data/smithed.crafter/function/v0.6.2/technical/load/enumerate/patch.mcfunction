execute if score #smithed.crafter.patch load.status matches ..2 unless score #smithed.crafter.patch load.status matches 2 run function smithed.crafter:v0.6.2/technical/load/enumerate/set_version
