schedule clear smithed.crafter:v0.6.2/technical/tick
execute if score #smithed.crafter.major load.status matches 0 if score #smithed.crafter.minor load.status matches 6 if score #smithed.crafter.patch load.status matches 2 run function smithed.crafter:v0.6.2/technical/load
