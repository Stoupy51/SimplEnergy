scoreboard players set #smithed.crafter.major load.status 0
scoreboard players set #smithed.crafter.minor load.status 6
scoreboard players set #smithed.crafter.patch load.status 2
scoreboard players set #smithed.crafter.set load.status 1
