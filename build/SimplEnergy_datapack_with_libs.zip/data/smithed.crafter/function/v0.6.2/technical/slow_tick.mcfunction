execute as @a at @s run function smithed.crafter:v0.6.2/entity/player/slow_tick

schedule function smithed.crafter:v0.6.2/technical/slow_tick 5 replace
