execute if score #smithed.crafter.patch load.status matches ..0 unless score #smithed.crafter.patch load.status matches 0 run function smithed.crafter:v0.7.0/technical/load/enumerate/set_version
