
#> simplenergy:custom_blocks/_player_head/search_elite_cable
#
# @within	advancement simplenergy:custom_block_head/elite_cable
#

# Search where the head has been placed



execute positioned ~-8 ~-8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~-1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~-1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~ ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~ ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~ ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~ ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~ ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~ ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~ ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~ ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~ ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~ ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~ ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~ ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~ ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~ ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~ ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~ ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~ ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-8 ~8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-8 ~8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~-1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~-1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~ ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~ ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~ ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~ ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~ ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~ ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~ ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~ ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~ ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~ ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~ ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~ ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~ ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~ ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~ ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~ ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~ ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-7 ~8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-7 ~8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~-1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~-1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~ ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~ ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~ ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~ ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~ ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~ ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~ ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~ ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~ ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~ ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~ ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~ ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~ ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~ ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~ ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~ ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~ ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-6 ~8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-6 ~8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~-1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~-1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~ ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~ ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~ ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~ ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~ ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~ ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~ ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~ ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~ ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~ ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~ ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~ ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~ ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~ ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~ ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~ ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~ ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-5 ~8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-5 ~8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~-1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~-1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~ ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~ ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~ ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~ ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~ ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~ ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~ ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~ ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~ ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~ ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~ ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~ ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~ ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~ ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~ ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~ ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~ ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-4 ~8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-4 ~8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~-1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~-1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~ ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~ ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~ ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~ ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~ ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~ ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~ ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~ ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~ ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~ ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~ ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~ ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~ ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~ ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~ ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~ ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~ ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-3 ~8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-3 ~8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~-1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~-1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~ ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~ ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~ ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~ ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~ ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~ ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~ ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~ ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~ ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~ ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~ ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~ ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~ ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~ ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~ ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~ ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~ ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-2 ~8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-2 ~8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~-1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~-1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~ ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~ ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~ ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~ ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~ ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~ ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~ ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~ ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~ ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~ ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~ ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~ ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~ ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~ ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~ ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~ ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~ ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~-1 ~8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~-1 ~8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~-1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~-1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~ ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~ ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~ ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~ ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~ ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~ ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~ ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~ ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~ ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~ ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~ ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~ ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~ ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~ ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~ ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~ ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~ ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~ ~8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~ ~8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~-1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~-1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~ ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~ ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~ ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~ ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~ ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~ ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~ ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~ ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~ ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~ ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~ ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~ ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~ ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~ ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~ ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~ ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~ ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~1 ~8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~1 ~8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~-1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~-1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~ ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~ ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~ ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~ ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~ ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~ ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~ ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~ ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~ ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~ ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~ ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~ ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~ ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~ ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~ ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~ ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~ ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~2 ~8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~2 ~8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~-1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~-1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~ ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~ ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~ ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~ ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~ ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~ ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~ ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~ ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~ ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~ ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~ ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~ ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~ ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~ ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~ ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~ ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~ ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~3 ~8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~3 ~8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~-1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~-1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~ ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~ ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~ ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~ ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~ ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~ ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~ ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~ ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~ ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~ ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~ ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~ ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~ ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~ ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~ ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~ ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~ ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~4 ~8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~4 ~8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~-1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~-1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~ ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~ ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~ ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~ ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~ ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~ ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~ ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~ ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~ ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~ ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~ ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~ ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~ ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~ ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~ ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~ ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~ ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~5 ~8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~5 ~8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~-1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~-1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~ ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~ ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~ ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~ ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~ ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~ ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~ ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~ ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~ ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~ ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~ ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~ ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~ ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~ ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~ ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~ ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~ ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~6 ~8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~6 ~8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~-1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~-1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~ ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~ ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~ ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~ ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~ ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~ ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~ ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~ ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~ ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~ ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~ ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~ ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~ ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~ ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~ ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~ ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~ ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~7 ~8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~7 ~8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~-1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~-1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~ ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~ ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~ ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~ ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~ ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~ ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~ ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~ ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~ ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~ ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~ ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~ ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~ ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~ ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~ ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~ ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~ ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~1 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~1 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~1 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~1 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~1 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~1 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~1 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~1 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~1 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~1 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~1 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~1 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~1 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~1 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~1 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~1 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~1 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~2 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~2 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~2 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~2 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~2 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~2 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~2 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~2 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~2 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~2 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~2 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~2 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~2 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~2 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~2 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~2 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~2 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~3 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~3 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~3 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~3 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~3 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~3 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~3 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~3 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~3 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~3 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~3 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~3 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~3 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~3 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~3 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~3 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~3 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~4 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~4 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~4 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~4 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~4 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~4 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~4 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~4 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~4 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~4 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~4 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~4 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~4 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~4 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~4 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~4 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~4 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~5 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~5 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~5 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~5 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~5 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~5 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~5 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~5 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~5 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~5 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~5 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~5 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~5 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~5 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~5 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~5 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~5 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~6 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~6 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~6 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~6 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~6 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~6 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~6 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~6 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~6 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~6 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~6 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~6 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~6 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~6 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~6 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~6 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~6 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~7 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~7 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~7 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~7 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~7 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~7 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~7 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~7 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~7 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~7 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~7 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~7 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~7 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~7 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~7 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~7 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~7 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~8 ~-8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~8 ~-7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~8 ~-6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~8 ~-5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~8 ~-4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~8 ~-3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~8 ~-2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~8 ~-1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~8 ~ if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~8 ~1 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~8 ~2 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~8 ~3 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~8 ~4 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~8 ~5 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~8 ~6 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

execute positioned ~8 ~8 ~7 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main
execute positioned ~8 ~8 ~8 if data block ~ ~ ~ components."minecraft:custom_data".simplenergy.elite_cable run function simplenergy:custom_blocks/elite_cable/place_main

advancement revoke @s only simplenergy:custom_block_head/elite_cable

